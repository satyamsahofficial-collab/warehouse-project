# Testing Instructions

## 1. Unit Tests
The unit tests are located in `test_system.cpp`. They verify the core functionality of the `Product`, `Employee`, `Order`, and `InventorySystem` classes.

### How to Run:
1. Open a terminal in the `TESTS` directory.
2. Compile the test file:
   ```bash
   g++ test_system.cpp -o ../BUILD/test_system
   ```
3. Run the executable:
   ```bash
   ../BUILD/test_system
   ```

## 2. User Acceptance Testing (UAT)
To perform UAT, run the main application and follow the scenarios described in the Technical Report.

### How to Run:
1. Open a terminal in the `SRC` directory.
2. Compile the main application:
   ```bash
   g++ main.cpp -o ../BUILD/warehouse_app
   ```
3. Run the application:
   ```bash
   ../BUILD/warehouse_app
   ```
