#include <iostream>
#include <cassert>
#include "../SRC/InventorySystem.h"

void testProduct() {
    Product p("Mouse", "M101", 100, "A1");
    assert(p.getName() == "Mouse");
    assert(p.getId() == "M101");
    assert(p.getQuantity() == 100);
    p.reduceQuantity(10);
    assert(p.getQuantity() == 90);
    std::cout << "Product test passed.\n";
}

void testEmployee() {
    Employee e("John", "E001");
    assert(e.getName() == "John");
    assert(e.getId() == "E001");
    std::cout << "Employee test passed.\n";
}

void testOrder() {
    std::vector<std::pair<std::string, int>> items = {{"M101", 5}};
    Order o("O101", items, "E001");
    assert(o.getOrderNumber() == "O101");
    assert(o.getStatus() == "Pending");
    o.setStatus("Done");
    assert(o.getStatus() == "Done");
    std::cout << "Order test passed.\n";
}

void testInventorySystem() {
    InventorySystem system;
    system.addProduct(Product("Mouse", "M101", 100, "A1"));
    system.addEmployee(Employee("John", "E001"));
    
    std::vector<std::pair<std::string, int>> items = {{"M101", 10}};
    system.addOrder(Order("O101", items, "E001"));
    
    system.completeOrder("O101");
    assert(system.findProduct("M101")->getQuantity() == 90);
    assert(system.findOrder("O101")->getStatus() == "Done");
    std::cout << "InventorySystem test passed.\n";
}

int main() {
    testProduct();
    testEmployee();
    testOrder();
    testInventorySystem();
    std::cout << "All tests passed!\n";
    return 0;
}
