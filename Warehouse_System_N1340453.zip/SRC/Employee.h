#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string>

class Employee {
private:
    std::string name;
    std::string id;

public:
    Employee(std::string name, std::string id)
        : name(name), id(id) {}

    std::string getName() const { return name; }
    std::string getId() const { return id; }

    void setName(std::string n) { name = n; }
};

#endif
