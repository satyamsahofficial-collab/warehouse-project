#ifndef INVENTORY_SYSTEM_H
#define INVENTORY_SYSTEM_H

#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <stdexcept>
#include "Product.h"
#include "Employee.h"
#include "Order.h"

class InventorySystem {
private:
    std::vector<Product> products;
    std::vector<Employee> employees;
    std::vector<Order> orders;

    // Helper to split string by delimiter
    std::vector<std::string> split(const std::string& s, char delimiter) {
        std::vector<std::string> tokens;
        std::string token;
        std::istringstream tokenStream(s);
        while (std::getline(tokenStream, token, delimiter)) {
            tokens.push_back(token);
        }
        return tokens;
    }

public:
    // Product Management
    void addProduct(const Product& p) {
        for (const auto& prod : products) {
            if (prod.getId() == p.getId()) {
                throw std::runtime_error("Product ID already exists.");
            }
        }
        products.push_back(p);
    }

    Product* findProduct(const std::string& id) {
        for (auto& p : products) {
            if (p.getId() == id) return &p;
        }
        return nullptr;
    }

    std::vector<Product*> searchProductsByName(const std::string& name) {
        std::vector<Product*> results;
        for (auto& p : products) {
            if (p.getName().find(name) != std::string::npos) {
                results.push_back(&p);
            }
        }
        return results;
    }

    const std::vector<Product>& getAllProducts() const { return products; }

    // Employee Management
    void addEmployee(const Employee& e) {
        for (const auto& emp : employees) {
            if (emp.getId() == e.getId()) {
                throw std::runtime_error("Employee ID already exists.");
            }
        }
        employees.push_back(e);
    }

    Employee* findEmployee(const std::string& id) {
        for (auto& e : employees) {
            if (e.getId() == id) return &e;
        }
        return nullptr;
    }

    const std::vector<Employee>& getAllEmployees() const { return employees; }

    // Order Management
    void addOrder(const Order& o) {
        for (const auto& ord : orders) {
            if (ord.getOrderNumber() == o.getOrderNumber()) {
                throw std::runtime_error("Order Number already exists.");
            }
        }
        orders.push_back(o);
    }

    Order* findOrder(const std::string& orderNumber) {
        for (auto& o : orders) {
            if (o.getOrderNumber() == orderNumber) return &o;
        }
        return nullptr;
    }

    std::vector<Order*> getOrdersByEmployee(const std::string& employeeId) {
        std::vector<Order*> results;
        for (auto& o : orders) {
            if (o.getAssignedEmployeeId() == employeeId) {
                results.push_back(&o);
            }
        }
        return results;
    }

    const std::vector<Order>& getAllOrders() const { return orders; }

    void completeOrder(const std::string& orderNumber) {
        Order* o = findOrder(orderNumber);
        if (!o) throw std::runtime_error("Order not found.");
        if (o->getStatus() == "Done") throw std::runtime_error("Order already completed.");

        // Check stock and reduce
        for (const auto& item : o->getItems()) {
            Product* p = findProduct(item.first);
            if (!p || p->getQuantity() < item.second) {
                throw std::runtime_error("Insufficient stock for product: " + item.first);
            }
        }

        for (const auto& item : o->getItems()) {
            Product* p = findProduct(item.first);
            p->reduceQuantity(item.second);
        }

        o->setStatus("Done");
    }

    // File Persistence
    void loadData() {
        loadProducts();
        loadEmployees();
        loadOrders();
    }

    void saveData() {
        saveProducts();
        saveEmployees();
        saveOrders();
    }

    void loadProducts() {
        std::ifstream file("products.csv");
        if (!file.is_open()) return;
        products.clear();
        std::string line;
        while (std::getline(file, line)) {
            auto tokens = split(line, ',');
            if (tokens.size() == 4) {
                products.emplace_back(tokens[0], tokens[1], std::stoi(tokens[2]), tokens[3]);
            }
        }
        file.close();
    }

    void saveProducts() {
        std::ofstream file("products.csv");
        for (const auto& p : products) {
            file << p.getName() << "," << p.getId() << "," << p.getQuantity() << "," << p.getLocation() << "\n";
        }
        file.close();
    }

    void loadEmployees() {
        std::ifstream file("employees.csv");
        if (!file.is_open()) return;
        employees.clear();
        std::string line;
        while (std::getline(file, line)) {
            auto tokens = split(line, ',');
            if (tokens.size() == 2) {
                employees.emplace_back(tokens[0], tokens[1]);
            }
        }
        file.close();
    }

    void saveEmployees() {
        std::ofstream file("employees.csv");
        for (const auto& e : employees) {
            file << e.getName() << "," << e.getId() << "\n";
        }
        file.close();
    }

    void loadOrders() {
        std::ifstream file("orders.csv");
        if (!file.is_open()) return;
        orders.clear();
        std::string line;
        while (std::getline(file, line)) {
            auto tokens = split(line, ',');
            if (tokens.size() >= 4) {
                std::string orderNum = tokens[0];
                std::string empId = tokens[1];
                std::string status = tokens[2];
                std::vector<std::pair<std::string, int>> items;
                for (size_t i = 3; i < tokens.size(); i += 2) {
                    if (i + 1 < tokens.size()) {
                        items.push_back({tokens[i], std::stoi(tokens[i+1])});
                    }
                }
                orders.emplace_back(orderNum, items, empId, status);
            }
        }
        file.close();
    }

    void saveOrders() {
        std::ofstream file("orders.csv");
        for (const auto& o : orders) {
            file << o.getOrderNumber() << "," << o.getAssignedEmployeeId() << "," << o.getStatus();
            for (const auto& item : o.getItems()) {
                file << "," << item.first << "," << item.second;
            }
            file << "\n";
        }
        file.close();
    }

    // Advanced Feature: Export Reports
    void exportInventoryReport(const std::string& filename) {
        std::ofstream file(filename);
        file << "Product Name,ID,Quantity,Location\n";
        for (const auto& p : products) {
            file << p.getName() << "," << p.getId() << "," << p.getQuantity() << "," << p.getLocation() << "\n";
        }
        file.close();
    }

    void exportOrdersReport(const std::string& filename, bool completedOnly) {
        std::ofstream file(filename);
        file << "Order Number,Employee ID,Status,Items\n";
        for (const auto& o : orders) {
            if (completedOnly && o.getStatus() != "Done") continue;
            if (!completedOnly && o.getStatus() == "Done") continue;
            file << o.getOrderNumber() << "," << o.getAssignedEmployeeId() << "," << o.getStatus();
            for (const auto& item : o.getItems()) {
                file << " | " << item.first << "(" << item.second << ")";
            }
            file << "\n";
        }
        file.close();
    }
};

#endif
