#ifndef PRODUCT_H
#define PRODUCT_H

#include <string>

class Product {
private:
    std::string name;
    std::string id;
    int quantity;
    std::string location;

public:
    Product(std::string name, std::string id, int quantity, std::string location)
        : name(name), id(id), quantity(quantity), location(location) {}

    std::string getName() const { return name; }
    std::string getId() const { return id; }
    int getQuantity() const { return quantity; }
    std::string getLocation() const { return location; }

    void setName(std::string n) { name = n; }
    void setQuantity(int q) { quantity = q; }
    void setLocation(std::string l) { location = l; }

    void reduceQuantity(int q) {
        if (quantity >= q) {
            quantity -= q;
        }
    }
};

#endif
