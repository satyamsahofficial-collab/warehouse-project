#ifndef ORDER_H
#define ORDER_H

#include <string>
#include <vector>
#include <utility>

class Order {
private:
    std::string orderNumber;
    std::vector<std::pair<std::string, int>> items; // Product ID and Quantity
    std::string assignedEmployeeId;
    std::string status; // "Pending", "Done"

public:
    Order(std::string orderNumber, std::vector<std::pair<std::string, int>> items, std::string assignedEmployeeId, std::string status = "Pending")
        : orderNumber(orderNumber), items(items), assignedEmployeeId(assignedEmployeeId), status(status) {}

    std::string getOrderNumber() const { return orderNumber; }
    std::vector<std::pair<std::string, int>> getItems() const { return items; }
    std::string getAssignedEmployeeId() const { return assignedEmployeeId; }
    std::string getStatus() const { return status; }

    void setStatus(std::string s) { status = s; }
    void setAssignedEmployeeId(std::string id) { assignedEmployeeId = id; }
    void setItems(std::vector<std::pair<std::string, int>> i) { items = i; }

    void addItem(std::string productId, int quantity) {
        items.push_back(std::make_pair(productId, quantity));
    }
};

#endif
