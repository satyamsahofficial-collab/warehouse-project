#include <iostream>
#include <string>
#include <vector>
#include <limits>
#include "InventorySystem.h"

using namespace std;

void clearInput() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

void managerMenu(InventorySystem& system) {
    int choice;
    while (true) {
        cout << "\n--- Manager Menu ---\n";
        cout << "1. Add Product\n";
        cout << "2. View Products\n";
        cout << "3. Edit Product\n";
        cout << "4. Add Employee\n";
        cout << "5. View Employees\n";
        cout << "6. Create Order\n";
        cout << "7. View Orders\n";
        cout << "8. Assign Order\n";
        cout << "9. Export Reports\n";
        cout << "0. Logout\n";
        cout << "Choice: ";
        if (!(cin >> choice)) {
            clearInput();
            continue;
        }
        clearInput();

        if (choice == 0) break;

        try {
            if (choice == 1) {
                string name, id, loc;
                int qty;
                cout << "Name: "; getline(cin, name);
                cout << "ID: "; getline(cin, id);
                cout << "Quantity: "; cin >> qty; clearInput();
                cout << "Location: "; getline(cin, loc);
                system.addProduct(Product(name, id, qty, loc));
                cout << "Product added.\n";
            } else if (choice == 2) {
                for (const auto& p : system.getAllProducts()) {
                    cout << "ID: " << p.getId() << " | Name: " << p.getName() << " | Qty: " << p.getQuantity() << " | Loc: " << p.getLocation() << endl;
                }
            } else if (choice == 3) {
                string id;
                cout << "Enter Product ID to edit: "; getline(cin, id);
                Product* p = system.findProduct(id);
                if (p) {
                    string name, loc;
                    int qty;
                    cout << "New Name (current: " << p->getName() << "): "; getline(cin, name);
                    cout << "New Quantity (current: " << p->getQuantity() << "): "; cin >> qty; clearInput();
                    cout << "New Location (current: " << p->getLocation() << "): "; getline(cin, loc);
                    p->setName(name); p->setQuantity(qty); p->setLocation(loc);
                    cout << "Product updated.\n";
                } else cout << "Product not found.\n";
            } else if (choice == 4) {
                string name, id;
                cout << "Name: "; getline(cin, name);
                cout << "ID: "; getline(cin, id);
                system.addEmployee(Employee(name, id));
                cout << "Employee added.\n";
            } else if (choice == 5) {
                for (const auto& e : system.getAllEmployees()) {
                    cout << "ID: " << e.getId() << " | Name: " << e.getName() << endl;
                }
            } else if (choice == 6) {
                string orderNum, empId;
                cout << "Order Number: "; getline(cin, orderNum);
                cout << "Assign to Employee ID: "; getline(cin, empId);
                vector<pair<string, int>> items;
                while (true) {
                    string prodId;
                    int qty;
                    cout << "Product ID (or 'done'): "; getline(cin, prodId);
                    if (prodId == "done") break;
                    cout << "Quantity: "; cin >> qty; clearInput();
                    items.push_back({prodId, qty});
                }
                system.addOrder(Order(orderNum, items, empId));
                cout << "Order created.\n";
            } else if (choice == 7) {
                for (const auto& o : system.getAllOrders()) {
                    cout << "Order #: " << o.getOrderNumber() << " | Emp: " << o.getAssignedEmployeeId() << " | Status: " << o.getStatus() << endl;
                }
            } else if (choice == 8) {
                string orderNum, empId;
                cout << "Order Number: "; getline(cin, orderNum);
                cout << "New Employee ID: "; getline(cin, empId);
                Order* o = system.findOrder(orderNum);
                if (o) {
                    o->setAssignedEmployeeId(empId);
                    cout << "Order reassigned.\n";
                } else cout << "Order not found.\n";
            } else if (choice == 9) {
                system.exportInventoryReport("inventory_report.csv");
                system.exportOrdersReport("completed_orders.csv", true);
                system.exportOrdersReport("pending_orders.csv", false);
                cout << "Reports exported to CSV.\n";
            }
        } catch (const exception& e) {
            cout << "Error: " << e.what() << endl;
        }
    }
}

void employeeMenu(InventorySystem& system, string empId) {
    int choice;
    while (true) {
        cout << "\n--- Employee Menu (ID: " << empId << ") ---\n";
        cout << "1. View Assigned Orders\n";
        cout << "2. Find Product\n";
        cout << "3. Complete Order\n";
        cout << "4. Export Order Reports\n";
        cout << "0. Logout\n";
        cout << "Choice: ";
        if (!(cin >> choice)) {
            clearInput();
            continue;
        }
        clearInput();

        if (choice == 0) break;

        try {
            if (choice == 1) {
                auto orders = system.getOrdersByEmployee(empId);
                for (auto o : orders) {
                    cout << "Order #: " << o->getOrderNumber() << " | Status: " << o->getStatus() << endl;
                    for (auto item : o->getItems()) {
                        cout << "  - " << item.first << " x " << item.second << endl;
                    }
                }
            } else if (choice == 2) {
                string search;
                cout << "Enter Product Name or ID: "; getline(cin, search);
                Product* p = system.findProduct(search);
                if (p) {
                    cout << "Found: " << p->getName() << " | Qty: " << p->getQuantity() << " | Loc: " << p->getLocation() << endl;
                } else {
                    auto results = system.searchProductsByName(search);
                    for (auto r : results) {
                        cout << "Found: " << r->getName() << " | ID: " << r->getId() << " | Qty: " << r->getQuantity() << " | Loc: " << r->getLocation() << endl;
                    }
                    if (results.empty()) cout << "No products found.\n";
                }
            } else if (choice == 3) {
                string orderNum;
                cout << "Enter Order Number to complete: "; getline(cin, orderNum);
                Order* o = system.findOrder(orderNum);
                if (o && o->getAssignedEmployeeId() == empId) {
                    system.completeOrder(orderNum);
                    cout << "Order completed and stock updated.\n";
                } else cout << "Order not found or not assigned to you.\n";
            } else if (choice == 4) {
                system.exportOrdersReport("completed_orders.csv", true);
                system.exportOrdersReport("pending_orders.csv", false);
                cout << "Reports exported to CSV.\n";
            }
        } catch (const exception& e) {
            cout << "Error: " << e.what() << endl;
        }
    }
}

int main() {
    InventorySystem system;
    system.loadData();

    int role;
    while (true) {
        cout << "\n--- Warehouse Inventory Management System ---\n";
        cout << "1. Manager Login\n";
        cout << "2. Employee Login\n";
        cout << "0. Exit\n";
        cout << "Role: ";
        if (!(cin >> role)) {
            clearInput();
            continue;
        }
        clearInput();

        if (role == 0) break;

        if (role == 1) {
            managerMenu(system);
        } else if (role == 2) {
            string empId;
            cout << "Enter Employee ID: "; getline(cin, empId);
            if (system.findEmployee(empId)) {
                employeeMenu(system, empId);
            } else {
                cout << "Invalid Employee ID.\n";
            }
        }
        system.saveData();
    }

    return 0;
}
